const gameBoard = document.createElement('div')
gameBoard.style.width = '400px'
gameBoard.style.height = '400px'
gameBoard.style.background = 'black'
gameBoard.style.position = 'relative'

document.body.appendChild(gameBoard)

export function drawSnake(snake) {
  gameBoard.innerHTML = ''

  snake.forEach(segment => {
    const snakeElement = document.createElement('div')
    snakeElement.style.position = 'absolute'
    snakeElement.style.width = '20px'
    snakeElement.style.height = '20px'
    snakeElement.style.background = 'lime'
    snakeElement.style.left = segment.x * 20 + 'px'
    snakeElement.style.top = segment.y * 20 + 'px'

    gameBoard.appendChild(snakeElement)
  })
}
